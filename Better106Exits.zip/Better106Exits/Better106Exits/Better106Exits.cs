﻿using System;
using Smod2;
using Smod2.Attributes;
using Smod2.EventHandlers;
using Smod2.Events;
using Smod2.API;
using static Smod2.API.Server;
using MEC;

namespace Better106Exits
{
    [PluginDetails(
        author = "moseechev",
        name = "Better106Exits",
        description = "Exits of 106's PD are now random",
        id = "mos.better106exits",
        version = "0.1",
        SmodMajor = 3,
        SmodMinor = 4,
        SmodRevision = 3
        )]
    public class Better106Exits : Smod2.Plugin
    {
        //public bool isEnabled = instance.GetConfigBool("b106exits_enabled");
        public static Better106Exits instance;
        public override void OnDisable()
        {
            
        }
        public override void OnEnable()
        {
            if (!Better106Exits.instance.GetConfigBool("b106exits_enabled"))
            {
                this.Warn("Somebody disabled this plugin.. no, i'm not crying.");
                PluginManager.DisablePlugin("mos.better106exits");
            }
            else
            {
                this.Info("Yay, better106exits is enabled! Have fun!");
            }
        }
        
        public override void Register()
        {
            instance = this;
            AddEventHandlers(new EventHandler());
            AddConfig(new Smod2.Config.ConfigSetting("b106exits_enabled", true, true, "Disables/enabled the plugin"));
        }


    }
    class EventHandler : IEventHandlerPocketDimensionExit
    {

        public int exit;
        public Vector doctor;
        public static System.Random rand = new Random();
        public Vector peanut;
        public Vector shyguy;
        public Vector guard;
        public Vector dog;
        public Vector scientist;
        public Vector mtf;

        public void OnPocketDimensionExit(PlayerPocketDimensionExitEvent ev)
        {
            if (!Better106Exits.instance.GetConfigBool("b106exits_enabled")) return;

            doctor = PluginManager.Manager.Server.Map.GetRandomSpawnPoint(Smod2.API.RoleType.SCP_049);
            peanut = PluginManager.Manager.Server.Map.GetRandomSpawnPoint(Smod2.API.RoleType.SCP_173);
            shyguy = PluginManager.Manager.Server.Map.GetRandomSpawnPoint(Smod2.API.RoleType.SCP_096);
            guard = PluginManager.Manager.Server.Map.GetRandomSpawnPoint(Smod2.API.RoleType.FACILITY_GUARD);
            dog = PluginManager.Manager.Server.Map.GetRandomSpawnPoint(Smod2.API.RoleType.SCP_939_89);
            scientist = PluginManager.Manager.Server.Map.GetRandomSpawnPoint(Smod2.API.RoleType.SCIENTIST);
            mtf = PluginManager.Manager.Server.Map.GetRandomSpawnPoint(Smod2.API.RoleType.NTF_COMMANDER);
            exit = rand.Next(0, 42);

            if (exit >= 0 && exit <= 5)
            {
                Timing.CallDelayed(0.2f, () => ev.Player.Teleport(guard));
            }

            if (exit >= 5 && exit <= 12)
            {
                Timing.CallDelayed(0.2f, () => ev.Player.Teleport(peanut));
            }

            if (exit >= 12 && exit <= 17)
            {
                Timing.CallDelayed(0.2f, () => ev.Player.Teleport(shyguy));
            }

            if (exit >= 17 && exit <= 26)
            {
                Timing.CallDelayed(0.2f, () => ev.Player.Teleport(scientist));
            }

            if (exit >= 26 && exit <= 33)
            {
                Timing.CallDelayed(0.2f, () => ev.Player.Teleport(dog));
            }

            if (exit >= 33 && exit <= 38)
            {
                Timing.CallDelayed(0.2f, () => ev.Player.Teleport(doctor));
            }

            if (exit >= 38 && exit >= 42)
            {
                Timing.CallDelayed(0.2f, () => ev.Player.Teleport(mtf));
            }
        }
    }
}
